
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from 'react-redux';
import AgGridReactTable from '../components/AgGridReactTable';
import Breadcrumb from '../components/Breadcrumb';



const Crud = () => {

    return (
        <div className="mx-auto max-w-270">
            <Breadcrumb pageName="Servicess" />
            
            <AgGridReactTable />
        </div>
    )
}
export default Crud;