import { createSlice } from '@reduxjs/toolkit'
import { fetchUserData } from '../../actions'


const initialState = {
    services: [],
    loading: false,
    error: null,
    selectedService: null,
    currentPage: 1,
    pageSize: 10,
    totalItems: 0,
    filters: {
        // Define your filter properties here
        // For example: status: 'active', category: 'software'
    },


}
export const LoginSlice = createSlice({
    name: 'service',
    initialState,
    reducers: {
        fetchServicesStart: (state) => {
            state.loading = true;
            state.error = null;
        },
        fetchServicesSuccess: (state, action) => {
            state.loading = false;
            state.services = action.payload;
        },
        fetchServicesFailure: (state, action) => {
            state.loading = false;
            state.error = action.payload;
        },
        selectService: (state, action) => {
            state.selectedService = action.payload;
        },
        clearSelectedService: (state) => {
            state.selectedService = null;
        },
        addService: (state, action) => {
            state.services.push(action.payload);
        },
        updateService: (state, action) => {
            const updatedService = action.payload;
            const index = state.services.findIndex(service => service.id === updatedService.id);
            if (index !== -1) {
                state.services[index] = updatedService;
            }
        },
        deleteService: (state, action) => {
            const serviceId = action.payload;
            state.services = state.services.filter(service => service.id !== serviceId);
        },

        setPage: (state, action) => {
            state.currentPage = action.payload;
        },

        setPageSize: (state, action) => {
            state.pageSize = action.payload;
        },

        setFilters: (state, action) => {
            state.filters = action.payload;
        },
    },
    extraReducers: {
        [fetchUserData.pending]: (state, action) => {
            state.loding = true
        },
        [fetchUserData.fulfilled]: (state, action) => {
            state.loding = false
            state.isAuthenticated = true
            state.jwt = action.payload.token
            saveJWT(action.payload.token);
        },
        [fetchUserData.rejected]: (state, action) => {
            state.loding = false
            state.error = action.error.message
        }
    }
})
export const { loginRequest, loginSuccess, loginFailure, setJWT, removeJWTtoken, setLoding } = LoginSlice.actions
export default LoginSlice.reducer