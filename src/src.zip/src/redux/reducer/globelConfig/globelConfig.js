import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  sidebarShow: false,
  loadingScreen:true,
  model:false,
}

export const globelConfigSlice = createSlice({
  name: 'globel',
  initialState,
  reducers: {
    toggleSidebar: (state,action ) => {
        return {...state,sidebarShow : action.payload}
    },
    toggleLoadingScreen: (state,action ) => {
        return {...state,loadingScreen : action.payload}
    },
    openModel:(state)=>{
      return {...state,model : true}
    },
    closeModel:(state)=>{
      return {...state,model : false}
    }
  },
})

// Action creators are generated for each case reducer function
export const { toggleSidebar , toggleLoadingScreen ,openModel, closeModel } = globelConfigSlice.actions

export default globelConfigSlice.reducer