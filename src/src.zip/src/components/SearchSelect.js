// import { useState } from "react";
// import Select from 'react-select'


// const options = [
//     { value: '1D', label: '1 Day' },
//     { value: '7D', label: '1 Week' },
//     { value: '1M', label: '1 Month' },
//     { value: '3M', label: '3 Months' },
//     { value: '1Y', label: '1 Year' }
// ];
// const SearchSelect = ({register}) => {
//     const [animal, setAnimal] = useState(null);

//     const handleChange = value => {
//         console.log("value:", value);
//         setAnimal(value);
//     };

//     return (
//         <Select
//             value={animal}
//             onChange={handleChange}
//             options={options}
//             menuPlacement="bottom"
//             menuPosition="fixed"
//             menuShouldScrollIntoView={false}
//             maxMenuHeight={150}
//             {...register("SearchSelect")}
            
//         />
//     );
// };

// export default SearchSelect;
import { Controller, useForm } from "react-hook-form";
import Select from "react-select";

const options = [
  { value: "fox", label: "🦊 Fox" },
  { value: "Butterfly", label: "🦋 Butterfly" },
  { value: "Honeybee", label: "🐝 Honeybee" }
];

const SearchSelect = ({control,errors}) => {


  return (
    <div>
      <Controller
        name="animal"
        control={control}
    
        render={({ field }) => (
          <div>
            <Select
              {...field}
              options={options}
            />
          
          </div>
        )}
      />
    </div>
  );
};

export default SearchSelect;
