const AgSearchBar = ({ searchText, handleSearch }) => {
  return (
    <div className="flex justify-start row-span-1 bg-red-200 p-6">
      <label htmlFor="search" className="mr-2">
        Search:
      </label>
      <input
        type="text"
        id="search"
        value={searchText}
        onChange={handleSearch}
        className="px-2 py-1 border border-gray-300 rounded"
      />
    </div>
  );
};

export default AgSearchBar;
