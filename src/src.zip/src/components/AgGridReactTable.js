import React, { useState, useRef } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import AgSearchBar from './AgSearchBar';
import { Data } from '../mock/Data'
import ExportToPDF from './ExportToPDF';
import PageSizeSelector from './PageSizeSelector';
import CreatExel from '../utils/CreatExel';
import ModalPopup from './ModalPopup';
import { useDispatch, useSelector } from 'react-redux';
import {openModel  } from '../redux/reducer/globelConfig/globelConfig'



const Edit = ({ make }) => {
    const dispatch = useDispatch();

    const toggleModal = () => {
        dispatch(openModel())

    };

    return (<button
        type="button"
        // className="inline-block rounded bg-primary px-6 pb-2 pt-2.5 text-xs font-medium uppercase leading-normal text-white shadow-[0_4px_9px_-4px_#3b71ca] transition duration-150 ease-in-out hover:bg-primary-600 hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:bg-primary-600 focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] focus:outline-none focus:ring-0 active:bg-primary-700 active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.3),0_4px_18px_0_rgba(59,113,202,0.2)] dark:shadow-[0_4px_9px_-4px_rgba(59,113,202,0.5)] dark:hover:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:focus:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)] dark:active:shadow-[0_8px_9px_-4px_rgba(59,113,202,0.2),0_4px_18px_0_rgba(59,113,202,0.1)]"
        data-te-toggle="modal"
        data-te-target="#exampleModal"
        data-te-ripple-init
        data-te-ripple-color="light"
        onClick={toggleModal}
    >
        Edit
    </button>)

}



const AgGridReactTable = () => {
    const apiRef = useRef(null); // Create a ref to store the grid API
    const rowData = Data;
    const [searchText, setSearchText] = useState('');
    const [paginationPageSize, setPagination] = useState(12);
    const columnDefs = [
        { checkboxSelection: true, headerCheckboxSelection: true, width: 40 },
        { field: 'make', sortable: true, filter: true },
        { field: 'model', sortable: true, filter: true },
        { field: 'price', sortable: true, filter: true },
        {
            headerName: "Action",
            field: "action",
            cellRenderer: (params) => <Edit make={params} />,
            width: 80,

        },
    ];

    const handleExport = () => {
        if (apiRef.current) {
            const gridApi = apiRef.current;
            const rowData = gridApi.getModel().rowsToDisplay.map((rowNode) => rowNode.data);
            CreatExel(rowData, 'CRUD');
        }
    };

    const handlePageSizeChange = (event) => {
        const newSize = parseInt(event.target.value);
        setPagination(newSize);
    };

    const onGridReady = (params) => {
        params.api.sizeColumnsToFit();
        apiRef.current = params.api; // Store the grid API in the ref
    };
    const handleSearch = (event) => {
        const newSearchText = event.target.value;
        setSearchText(newSearchText);
        if (apiRef.current) {
            apiRef.current.setQuickFilter(newSearchText); // Use apiRef.current to access the grid API
        }
    };


    return (
        <>
            <div className="grid grid-cols-2 gap-1">
                <div>
                    <button className="btn btn-primary" onClick={handleExport}>
                        Export to Exel
                        /
                        <button className="btn btn-primary ml-2" onClick={handleExport}>
                            <ExportToPDF data={rowData} />
                        </button>
                    </button>
                </div>
                <div className="flex justify-end mr-6">
                    <button className='text-white bg-primary bg-blue-500 hover:bg-blue-600 py-2 px-4 rounded' >
                        <b> + Add  </b>
                    </button>

                </div>

            </div>




            <div className="grid grid-cols-2 gap-4">
                <AgSearchBar searchText={searchText} handleSearch={handleSearch} />
                <PageSizeSelector handlePageSizeChange={handlePageSizeChange} />
            </div>

            <div className="ag-theme-alpine" style={{ height: 400, width: '100%' }}>
                <AgGridReact
                    rowData={rowData}
                    columnDefs={columnDefs}
                    pagination={true}
                    paginationPageSize={paginationPageSize}
                    domLayout='autoHeight'
                    quickFilterText=''
                    rowSelection='multiple'
                    ref={apiRef} // Set the ref to access the grid API
                    onGridReady={onGridReady}
                />
            </div>

        </>
    );
};

export default AgGridReactTable;

