import React from 'react';
import PropTypes from 'prop-types';

const PageSizeSelector = ({ handlePageSizeChange, max }) => {
    let options = [10, 25, 50, 100];
    if (max < 1000) {
        options.push(max);
    }
    return (
        <div className="flex justify-end bg-blue-200 p-6">
            <label htmlFor="pageSize" className="mr-2">Page Size:</label>
            <select
                id="pageSize"
                className="px-2 py-1 border border-gray-300 rounded"
                onChange={handlePageSizeChange}
            >
                {options.map((option) => (
                    <option key={option} value={option}>
                         {option === max ? 'ALL' : option}
                    </option>
                ))}
            </select>
        </div>
    );
};


PageSizeSelector.propTypes = {
    handlePageSizeChange: PropTypes.func.isRequired,
    max: PropTypes.number,
};

export default PageSizeSelector;
