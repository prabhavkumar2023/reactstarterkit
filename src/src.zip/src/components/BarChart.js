import Chart from "chart.js/auto";
import { CategoryScale } from "chart.js";
import { useState, useEffect, useRef } from "react";

export const Data = [
  {
    id: 1,
    year: 2016,
    userGain: 80000,
    userLost: 823,
  },
  {
    id: 2,
    year: 2017,
    userGain: 45677,
    userLost: 345,
  },
  {
    id: 3,
    year: 2018,
    userGain: 78888,
    userLost: 555,
  },
  {
    id: 4,
    year: 2019,
    userGain: 90000,
    userLost: 4555,
  },
  {
    id: 5,
    year: 2020,
    userGain: 4300,
    userLost: 234,
  },
];

Chart.register(CategoryScale);

function BarChart() {
  const chartRef = useRef(null);

  useEffect(() => {
    createChart();
  }, []);

  const createChart = () => {
    const labels = Data.map((entry) => entry.year);
    const userGainData = Data.map((entry) => entry.userGain);
    const userLostData = Data.map((entry) => entry.userLost);

    const data = {
      labels: labels,
      datasets: [
        {
          label: "User Gain",
          data: userGainData,
          backgroundColor: "rgba(75, 192, 192, 0.2)",
          borderColor: "rgba(75, 192, 192, 1)",
          borderWidth: 1,
        },
        {
          label: "User Lost",
          data: userLostData,
          backgroundColor: "rgba(255, 99, 132, 0.2)",
          borderColor: "rgba(255, 99, 132, 1)",
          borderWidth: 1,
        },
      ],
    };

    new Chart(chartRef.current, {
      type: "bar",
      data: data,
      options: {
        scales: {
          y: {
            beginAtZero: true,
          },
        },
      },
    });
  };

  return <canvas ref={chartRef}></canvas>;
}

export default BarChart;
