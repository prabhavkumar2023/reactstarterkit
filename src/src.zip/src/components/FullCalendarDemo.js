import React, { useState } from 'react';
import { formatDate } from '@fullcalendar/core';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';

export function getHashValues(hash) {
    return Object.values(hash) // needs modern browser
  }
  
  export function hashById(array) {
    let hash = {}
  
    for (let item of array) {
      hash[item.id] = item
    }
  
    return hash
  }
  
  export function excludeById(array, id) {
    return array.filter((item) => item.id !== id)
  }
  
  export function getTodayStr() {
    return new Date().toISOString().replace(/T.*$/, '')
  }
  

function FullCalendarDemo() {
  const [weekendsVisible, setWeekendsVisible] = useState(false);
  const [events, setEvents] = useState([]); // Local state to manage events

  const renderEventContent = (eventInfo) => (
    <>
      <b>{eventInfo.timeText}</b>
      <i>{eventInfo.event.title}</i>
    </>
  );

  const renderSidebarEvent = (plainEventObject) => (
    <li key={plainEventObject.id}>
      <b>{formatDate(plainEventObject.start, { year: 'numeric', month: 'short', day: 'numeric' })}</b>
      <i>{plainEventObject.title}</i>
    </li>
  );

  const reportNetworkError = () => {
    alert('This action could not be completed');
  };

  const handleDateSelect = (selectInfo) => {
    let calendarApi = selectInfo.view.calendar;
    let title = prompt('Please enter a new title for your event');

    calendarApi.unselect(); // clear date selection

    if (title) {
      const newEvent = {
        title,
        start: selectInfo.startStr,
        end: selectInfo.endStr,
        allDay: selectInfo.allDay,
      };
      setEvents([...events, newEvent]);
    }
  };

  const handleEventClick = (clickInfo) => {

    // if (confirm(`Are you sure you want to delete the event '${clickInfo.event.title}'`)) {
    //   const updatedEvents = events.filter(event => event.id !== clickInfo.event.id);
    //   setEvents(updatedEvents);
    // }
  };

  const handleDates = (rangeInfo) => {
    // Fetch events based on rangeInfo and update the local events state
    // Example API call: fetchEvents(rangeInfo.startStr, rangeInfo.endStr)
    // .then(data => setEvents(data))
    reportNetworkError();
  };

  return (
    <div className='demo-app'>
      {/* {renderSidebar()} */}
      <div className='demo-app-main'>
        <FullCalendar
          plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
          headerToolbar={{
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay',
          }}
          initialView='dayGridMonth'
          editable={true}
          selectable={true}
          selectMirror={true}
          dayMaxEvents={true}
          weekends={weekendsVisible}
          datesSet={handleDates}
          select={handleDateSelect}
        
          events={events}
          eventContent={renderEventContent} // custom render function
          eventClick={handleEventClick}
          nowIndicator={true}
        />

      </div>
    </div>
  );
}

export default FullCalendarDemo;
