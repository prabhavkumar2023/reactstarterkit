import * as XLSX from 'xlsx';


const CreatExel = (rowData,filename='data') => {
    const ws = XLSX.utils.json_to_sheet(rowData);
    const currentTime = new Date().toISOString().replace(/:/g, ''); // Get the current time as a string without colons
    const wb = XLSX.utils.book_new();

    // Add bold style to the first row (header row)
    const firstRow = XLSX.utils.sheet_add_json(ws, rowData, { origin: 'A1' });
    XLSX.utils.format_cell(firstRow[0], { font: { bold: true } });
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

    const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const fileName = `${filename}_${currentTime}.xlsx`;
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(url);

}
export default CreatExel;